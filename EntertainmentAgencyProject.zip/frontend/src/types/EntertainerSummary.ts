export interface EntertainerSummary {
    entertainerID: number;
    entStageName: string;
    bookingCount: number;
    lastBookingDate: string;
  }

  